$(document).ready(function(){
           
    $('#output').load("/templates/output.htm");
 
 });